extends Node

var p1_team: Array = []
var p2_team: Array = []
