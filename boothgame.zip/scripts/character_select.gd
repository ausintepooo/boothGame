extends Control

@onready var status_label = $StatusLabel
@onready var fight_button = $FightButton

func _ready():
	Global.p1_team.clear()
	Global.p2_team.clear()
	update_ui()

func pick_character(char_name: String):
	if Global.p1_team.size() < 3:
		Global.p1_team.append(char_name)
	elif Global.p2_team.size() < 3:
		Global.p2_team.append(char_name)
	update_ui()

func update_ui():
	if Global.p1_team.size() < 3:
		status_label.text = "PLAYER 1: Pick " + str(3 - Global.p1_team.size()) + " more\nTeam: " + ", ".join(Global.p1_team)
	elif Global.p2_team.size() < 3:
		status_label.text = "PLAYER 2: Pick " + str(3 - Global.p2_team.size()) + " more\nTeam: " + ", ".join(Global.p2_team)
	else:
		status_label.text = "READY TO CLASH!\nP1: " + ", ".join(Global.p1_team) + "  VS  P2: " + ", ".join(Global.p2_team)
		fight_button.disabled = false

# --- BUTTON SIGNALS ---
func _on_warriorbtn_pressed():
	pick_character("Warrior")

func _on_archerbtn_pressed():
	pick_character("Archer")

func _on_lancerbtn_pressed():
	pick_character("Lancer")

func _on_monkbtn_pressed():
	pick_character("Monk")

func _on_pawnbttn_pressed():
	pick_character("Pawn")

func _on_fight_button_pressed():
	print("P1: ", Global.p1_team, " vs P2: ", Global.p2_team)
	# Dito natin ilalagay ang lipat sa battle_arena.tscn sa susunod na step!
